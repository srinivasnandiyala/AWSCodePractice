def sum(a,b):
    return a+b

def square(n):
    return n**2

def diff_cust(a,b):
    if a > b :
        return a-b
    else:
        return b-a
